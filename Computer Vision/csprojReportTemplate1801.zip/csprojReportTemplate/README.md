This directory contains an example of a LaTeX report suitable for CS
Projects. It has been adapted from a template ANU thesis and contains
some examples of how to typeset code listings, figures and tables in a
computer science context.

It requires a full LaTeX installation along with pdflatex. To build
the report, type the command:
    make
To delete intermediate files, type the command:
    make clean